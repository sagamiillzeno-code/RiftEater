package com.rifteater.item;

import com.rifteater.entity.EntityRiftEater;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class ItemSummoningSigil extends Item {
    public ItemSummoningSigil() {
        setMaxStackSize(1);
    }

    @Override
    public EnumActionResult onItemUse(EntityPlayer player, World world, BlockPos pos,
                                      net.minecraft.util.EnumHand hand,
                                      net.minecraft.util.EnumFacing facing,
                                      float hitX, float hitY, float hitZ) {
        if (!world.isRemote) {
            BlockPos spawn = pos.offset(facing).up();
            if (world.isAirBlock(spawn) && world.isAirBlock(spawn.up())) {
                EntityRiftEater boss = new EntityRiftEater(world);
                boss.setPosition(spawn.getX() + 0.5D, spawn.getY(), spawn.getZ() + 0.5D);
                world.spawnEntity(boss);
                if (!player.capabilities.isCreativeMode) {
                    player.getHeldItem(hand).shrink(1);
                }
                return EnumActionResult.SUCCESS;
            }
            return EnumActionResult.FAIL;
        }
        return EnumActionResult.SUCCESS;
    }
}
