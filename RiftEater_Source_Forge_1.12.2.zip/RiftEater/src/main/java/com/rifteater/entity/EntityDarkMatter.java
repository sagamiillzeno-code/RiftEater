package com.rifteater.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class EntityDarkMatter extends EntityThrowable {
    public EntityDarkMatter(World worldIn) {
        super(worldIn);
    }

    public EntityDarkMatter(World worldIn, EntityLivingBase throwerIn) {
        super(worldIn, throwerIn);
    }

    @Override
    protected void onImpact(RayTraceResult result) {
        if (world.isRemote) return;
        if (result.entityHit != null && result.entityHit != getThrower()) {
            result.entityHit.attackEntityFrom(DamageSource.causeIndirectMagicDamage(this, getThrower()), 14.0F);
            if (result.entityHit instanceof EntityLivingBase) {
                ((EntityLivingBase) result.entityHit).addPotionEffect(
                    new net.minecraft.potion.PotionEffect(net.minecraft.init.MobEffects.SLOWNESS, 50, 0));
            }
        }
        for (int i = 0; i < 20; i++) {
            world.spawnParticle(EnumParticleTypes.SPELL_WITCH, posX, posY, posZ,
                (rand.nextDouble() - 0.5D) * 0.4D, rand.nextDouble() * 0.3D,
                (rand.nextDouble() - 0.5D) * 0.4D);
        }
        setDead();
    }
}
