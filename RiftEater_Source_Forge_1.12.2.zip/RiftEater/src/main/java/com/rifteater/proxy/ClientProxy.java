package com.rifteater.proxy;

import com.rifteater.entity.EntityDarkMatter;
import com.rifteater.entity.EntityRiftEater;
import com.rifteater.registry.ModItems;
import com.rifteater.client.RenderRiftEater;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderSnowball;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityRiftEater.class, RenderRiftEater::new);
        RenderingRegistry.registerEntityRenderingHandler(EntityDarkMatter.class,
            manager -> new RenderSnowball<EntityDarkMatter>(manager, ModItems.DARK_MATTER,
                Minecraft.getMinecraft().getRenderItem()));
    }
}
